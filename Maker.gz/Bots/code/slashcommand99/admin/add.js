const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/codeDB.json")

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('add')
    .setDescription('اضافة كود')
  .addStringOption(text => text
    .setName(`code-name`)
    .setDescription(`اسم كود`)
    .setRequired(true))
.addStringOption(text => text
    .setName(`code-price`)
    .setDescription(`سعر كود`)
    .setRequired(true))
 .addStringOption(text => text
    .setName(`code-line`)
    .setDescription(`لنك كود`)
    .setRequired(true)),
  
  async execute(interaction) {


    const codeName = interaction.options.getString('code-name');
    const codePrice = interaction.options.getString('code-price');
    const codeLink = interaction.options.getString('code-line');

    if(isNaN(codePrice)) return interaction.reply({ content: `**قم إدخال سعر كود بطريقة صحيحة.**`, ephemeral:true });

    db.push(`codes_${interaction.guild.id}`, {
      codeName: codeName,
      codePrice: codePrice,
      codeLink: codeLink
    });

    interaction.reply({ content: `**تم إضافة كود بنجاح**`, ephemeral:true  });
    
  }
}