const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/toolsDB.json")

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('add')
    .setDescription('اضافة كود')
  .addStringOption(text => text
    .setName(`tools-name`)
    .setDescription(`اسم ادات`)
    .setRequired(true))
.addStringOption(text => text
    .setName(`tools-price`)
    .setDescription(`سعر ادات`)
    .setRequired(true))
 .addStringOption(text => text
    .setName(`tools-line`)
    .setDescription(`لنك ادات`)
    .setRequired(true)),
  
  async execute(interaction) {


    const toolsName = interaction.options.getString('tools-name');
    const toolsPrice = interaction.options.getString('tools-price');
    const toolsLink = interaction.options.getString('tools-line');

    if(isNaN(toolsPrice)) return interaction.reply({ content: `**قم إدخال سعر ادات بطريقة صحيحة.**`, ephemeral:true });

    db.push(`toolss_${interaction.guild.id}`, {
      toolsName: toolsName,
      toolsPrice: toolsPrice,
      toolsLink: toolsLink
    });

    interaction.reply({ content: `**تم إضافة ادات بنجاح**`, ephemeral:true  });
    
  }
}