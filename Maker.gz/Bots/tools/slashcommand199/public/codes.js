const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/codeDB.json")

module.exports = {
    ownersOnly:false,
    data: new SlashCommandBuilder()
    .setName('اكواد')
    .setDescription('لروئية اكواد باسعارها'),
  
  async execute(interaction) { 
    const codes = await db.get(`codes_${interaction.guild.id}`);
    if (!codes || codes.length === 0) {
      return interaction.reply({ content: `**لا توجد بيانات متاحة حالياً.**`, ephemeral: true });
    } else {
      let response = '**اكواد متاحة :**\n';
      codes.forEach(code => {
        response += `- **الاسم : ${code.codeName}** \n- **السعر : ${code.codePrice}** \n`;
      });
      return interaction.reply({ content: response, ephemeral: true });
    }
  }
}